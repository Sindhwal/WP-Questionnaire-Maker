<?php
/**
*
*	Silence is golden
*
*
*/